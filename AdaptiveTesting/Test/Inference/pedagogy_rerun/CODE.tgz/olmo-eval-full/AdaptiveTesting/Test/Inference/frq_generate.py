"""FRQ (free-response) generation: render faithful tutor prompts, generate, and
durably store the Model Output schema.

Ported from eduLLM-Evals ``respgen/runner.py`` and adapted to this repo's
resident-engine model. What it preserves from respgen, and why:

  * **Prompt fidelity** - the full multi-turn message list (per-benchmark or
    per-use_case system turn + conversation history, coalesced to alternate) via
    :mod:`frq_prompts`, with a flat ``Student:``/``Tutor:`` fallback for base
    models with no chat template.
  * **Per-item generation budget** - the prompt is fit to
    ``max_model_len - MIN_GEN`` by protecting the system turn and final user
    turn (eliding interior history, then the middle of a long user body), then
    each item decodes with ``min(max_new_tokens, max_model_len - prompt_tokens)``,
    never below MIN_GEN. Prompts that still cannot fit become Issue cells
    (``prompt_too_long``) rather than silently head-truncated generations.
  * **Failure isolation** - a generation error writes an Issue row for every
    outstanding scenario, so the (model, scenario) matrix is never left with holes.
  * **Validity-aware resume** - see :mod:`frq_shard`; Issue / legacy head-trunc
    rows regenerate.

Responses are persisted here and never judged inline: a judge failure can't lose
generations (run ``judge_all.py`` afterwards).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import frq_prompts as P
import frq_records as R
from common import open_responses_path
from config import WriterConfig
from engine import Engine, GenParams
from frq_shard import rewrite_shard, scan_shard
from models_registry import ModelSpec
from results_writer import JsonlResultWriter

# Always leave at least this many tokens for the model to answer. The prompt is
# truncated to (max_model_len - MIN_GEN) first; generation then takes whatever
# context is left.
MIN_GEN = 256

HISTORY_OMITTED = "[…earlier conversation omitted…]"
BODY_OMITTED = "[…middle omitted…]"


@dataclass
class FRQResult:
    written: int
    complete: bool  # every scenario now has a valid row (safe to mark pair done)
    status: str = "ok"


@dataclass
class _FitResult:
    text: str
    prompt_tokens: int
    truncated: bool
    gen_budget: int
    strategy: str  # none | history_elided | body_elided | prompt_too_long
    full_prompt: str  # untruncated render (for audit on prompt_too_long)
    chat_applied: bool
    too_long: bool


def _resolve_revision(model_id: str, override: str | None) -> str:
    """Pin the exact commit for provenance. Empty string if the Hub is
    unreachable (recorded as-is; the default branch is then used at load)."""
    if override:
        return override
    try:
        from huggingface_hub import HfApi  # lazy

        return HfApi().model_info(model_id).sha or ""
    except Exception:
        return ""


def _token_len(text: str, tokenizer) -> int:
    if tokenizer is None:
        return max(1, len(text) // 4)
    return len(tokenizer(text, add_special_tokens=False)["input_ids"])


def _render_messages(
    engine: Engine, spec: ModelSpec, messages: list[dict[str, str]]
) -> tuple[str, bool]:
    """(rendered prompt, chat_template_applied)."""
    text, applied = engine.render_chat(messages, getattr(spec, "enable_thinking", None))
    if applied:
        return text, True
    return P.render_base_from_messages(messages), False


def _split_messages(
    messages: list[dict[str, str]],
) -> tuple[list[dict[str, str]], list[dict[str, str]], list[dict[str, str]]]:
    """Split into (system_turns, interior, final_user_turn)."""
    if not messages:
        return [], [], []
    system: list[dict[str, str]] = []
    rest = messages
    if messages[0]["role"] == "system":
        system = [messages[0]]
        rest = messages[1:]
    if not rest:
        return system, [], []
    return system, list(rest[:-1]), [rest[-1]]


def _assemble(
    system: list[dict[str, str]],
    interior: list[dict[str, str]],
    final: list[dict[str, str]],
    *,
    history_elided: bool,
) -> list[dict[str, str]]:
    out: list[dict[str, str]] = list(system)
    if history_elided:
        out.append({"role": "user", "content": HISTORY_OMITTED})
    out.extend(interior)
    out.extend(final)
    return P.normalize(out)


def _elide_body(text: str, tokenizer, budget_tokens: int) -> str | None:
    """Keep opening + closing spans of ``text`` so it fits ``budget_tokens``.

    Returns None when even a marker-sized stub cannot fit.
    """
    if budget_tokens < 1:
        return None
    if _token_len(text, tokenizer) <= budget_tokens:
        return text
    if tokenizer is None:
        cap = budget_tokens * 4
        marker = BODY_OMITTED
        room = cap - len(marker)
        if room < 2:
            return None
        head = room // 2
        tail = room - head
        return text[:head] + marker + text[-tail:]

    ids = tokenizer(text, add_special_tokens=False)["input_ids"]
    marker_ids = tokenizer(BODY_OMITTED, add_special_tokens=False)["input_ids"]
    room = budget_tokens - len(marker_ids)
    if room < 2:
        return None
    head_n = room // 2
    tail_n = room - head_n
    new_ids = ids[:head_n] + marker_ids + ids[-tail_n:]
    return tokenizer.decode(new_ids, skip_special_tokens=False)


def _gen_budget(prompt_tokens: int, max_model_len: int, max_new_tokens: int) -> int:
    gen_budget = min(max_new_tokens, max(MIN_GEN, max_model_len - prompt_tokens))
    return max(1, min(gen_budget, max_model_len - 1))


def _fit_prompt_and_budget(
    engine: Engine,
    spec: ModelSpec,
    scenario,
    tokenizer,
    max_model_len: int,
    max_new_tokens: int,
) -> _FitResult:
    """Fit the prompt at the message level; size this item's generation budget.

    Policy (construct-valid for system-first FRQ prompts):
      1. Keep the system turn and final user turn.
      2. Drop interior conversation_context turns oldest-first, with a visible
         omission marker.
      3. If still over, elide the middle of the final user body.
      4. If system + final user still cannot fit, mark prompt_too_long (no gen).
    """
    prompt_cap = max(1, max_model_len - MIN_GEN)
    messages = P.build_chat_messages(scenario)
    full_text, chat_applied = _render_messages(engine, spec, messages)
    full_tokens = _token_len(full_text, tokenizer)

    if full_tokens <= prompt_cap:
        return _FitResult(
            text=full_text,
            prompt_tokens=full_tokens,
            truncated=False,
            gen_budget=_gen_budget(full_tokens, max_model_len, max_new_tokens),
            strategy="none",
            full_prompt=full_text,
            chat_applied=chat_applied,
            too_long=False,
        )

    system, interior, final = _split_messages(messages)
    had_interior = bool(interior)
    if not final:
        # Degenerate: nowhere to anchor; refuse rather than head-truncate.
        return _FitResult(
            text=full_text,
            prompt_tokens=full_tokens,
            truncated=True,
            gen_budget=MIN_GEN,
            strategy="prompt_too_long",
            full_prompt=full_text,
            chat_applied=chat_applied,
            too_long=True,
        )

    strategy = "none"
    working_interior = list(interior)
    text, chat_applied = full_text, chat_applied
    prompt_tokens = full_tokens

    while working_interior and prompt_tokens > prompt_cap:
        working_interior.pop(0)  # oldest first
        strategy = "history_elided"
        fitted = _assemble(system, working_interior, final, history_elided=True)
        text, chat_applied = _render_messages(engine, spec, fitted)
        prompt_tokens = _token_len(text, tokenizer)

    if prompt_tokens <= prompt_cap:
        return _FitResult(
            text=text,
            prompt_tokens=prompt_tokens,
            truncated=True,
            gen_budget=_gen_budget(prompt_tokens, max_model_len, max_new_tokens),
            strategy=strategy,
            full_prompt=full_text,
            chat_applied=chat_applied,
            too_long=False,
        )

    # System + final user (plus optional history marker) still overflow: elide
    # the interior of the final user turn so instruction framing survives.
    strategy = "body_elided"
    final_body = final[0]["content"]
    # Binary-search a body budget by measuring the rendered prompt.
    lo, hi = 1, max(1, _token_len(final_body, tokenizer))
    best: _FitResult | None = None
    while lo <= hi:
        mid = (lo + hi) // 2
        elided_body = _elide_body(final_body, tokenizer, mid)
        if elided_body is None:
            hi = mid - 1
            continue
        trial_final = [{"role": final[0]["role"], "content": elided_body}]
        fitted = _assemble(
            system, [], trial_final, history_elided=had_interior
        )
        trial_text, trial_applied = _render_messages(engine, spec, fitted)
        trial_tokens = _token_len(trial_text, tokenizer)
        if trial_tokens <= prompt_cap:
            best = _FitResult(
                text=trial_text,
                prompt_tokens=trial_tokens,
                truncated=True,
                gen_budget=_gen_budget(trial_tokens, max_model_len, max_new_tokens),
                strategy=strategy,
                full_prompt=full_text,
                chat_applied=trial_applied,
                too_long=False,
            )
            lo = mid + 1  # try keeping more body
        else:
            hi = mid - 1

    if best is not None:
        return best

    return _FitResult(
        text=full_text,
        prompt_tokens=full_tokens,
        truncated=True,
        gen_budget=MIN_GEN,
        strategy="prompt_too_long",
        full_prompt=full_text,
        chat_applied=chat_applied,
        too_long=True,
    )


def _count_output_tokens(tokenizer, text: str) -> int:
    if tokenizer is None:
        return len(text.split())
    try:
        return len(tokenizer(text, add_special_tokens=False)["input_ids"])
    except Exception:
        return len(text.split())


def generate_frq(
    engine: Engine,
    spec: ModelSpec,
    benchmark_key: str,
    scenarios: list,
    writer_cfg: WriterConfig,
    *,
    resume: bool = True,
    overrides: dict[str, Any] | None = None,
) -> FRQResult:
    """Generate + persist FRQ responses for one (benchmark, model) pair.

    Decoding defaults come from the model manifest (respgen parity); ``overrides``
    (inference.yaml ``generation`` + per-benchmark ``overrides``) can adjust
    max_new_tokens / temperature / top_p / seed / repetition_penalty.
    """
    ov = overrides or {}

    def _eff(name: str, default):
        val = ov.get(name)
        if val is None:
            val = getattr(spec, name, None)
        return default if val is None else val
    out_path = open_responses_path(benchmark_key, spec.id)
    label = getattr(scenarios[0], "benchmark", "") if scenarios else ""
    label = label or R.BENCHMARK

    # Validity-aware resume: only scenarios with a valid row count as done, and
    # any Issue / corrupted / duplicate rows are compacted out first so the shard
    # ends with exactly one clean row per scenario.
    done: set[str] = set()
    if resume:
        done, valid_rows, had_invalid = scan_shard(out_path)
        if had_invalid:
            rewrite_shard(out_path, valid_rows)
    else:
        rewrite_shard(out_path, [])

    todo = [s for s in scenarios if s.scenario_id not in done]
    if not todo:
        return FRQResult(written=0, complete=True, status="already_complete")

    # The engine was built with spec.max_model_len; the cap can only lower the
    # window we fit prompts into (never raise it past what the engine allocated).
    max_model_len = min(
        int(getattr(spec, "max_model_len", 4096) or 4096),
        int(getattr(spec, "max_model_len_cap", 32768) or 32768),
    )
    max_new_tokens = int(_eff("max_new_tokens", 4096))
    revision = _resolve_revision(spec.id, getattr(spec, "revision", None))
    tokenizer = engine.tokenizer

    fits: list[_FitResult] = [
        _fit_prompt_and_budget(
            engine, spec, s, tokenizer, max_model_len, max_new_tokens
        )
        for s in todo
    ]

    # Generate only for prompts that fit (possibly after elision).
    gen_indices = [i for i, f in enumerate(fits) if not f.too_long]
    gen_prompts = [fits[i].text for i in gen_indices]
    gen_budgets = [fits[i].gen_budget for i in gen_indices]

    params = GenParams(
        temperature=float(_eff("temperature", 0.0)),
        top_p=float(_eff("top_p", 1.0)),
        max_tokens=max_new_tokens,
        seed=int(_eff("seed", 0)),
        repetition_penalty=float(_eff("repetition_penalty", 1.1)),
    )

    t0 = time.monotonic()
    gen_error: str | None = None
    outputs: list[str] | None = None
    finish_reasons: list[str] | None = None
    try:
        if gen_prompts:
            outputs, finish_reasons = engine.generate(
                gen_prompts,
                params,
                pre_rendered=True,
                max_tokens_per_prompt=gen_budgets,
                return_finish_reasons=True,
            )
        else:
            outputs, finish_reasons = [], []
    except Exception as exc:  # noqa: BLE001 - isolate to Issue cells, never lose the pair
        outputs = None
        finish_reasons = None
        gen_error = repr(exc)
    elapsed = time.monotonic() - t0
    avg_latency = round(elapsed / len(todo), 4) if todo else None

    out_by_todo: dict[int, tuple[str, str]] = {}
    if outputs is not None:
        for j, i in enumerate(gen_indices):
            out_by_todo[i] = (outputs[j], finish_reasons[j] if finish_reasons else "stop")

    written = 0
    with JsonlResultWriter(
        out_path,
        fsync_every_rows=writer_cfg.fsync_every_rows,
        fsync_every_seconds=writer_cfg.fsync_every_seconds,
    ) as w:
        for i, s in enumerate(todo):
            fit = fits[i]
            gp = R.generation_params(
                params.temperature, params.top_p, fit.gen_budget,
                params.repetition_penalty, params.seed,
            )
            if fit.too_long:
                rec = R.error_record(
                    scenario_id=s.scenario_id,
                    model_id=spec.id,
                    model_revision=revision,
                    rendered_prompt=fit.full_prompt,
                    gen_params=gp,
                    max_model_len=max_model_len,
                    description=(
                        f"prompt_too_long: needs {fit.prompt_tokens} tokens, "
                        f"window {max_model_len}"
                    ),
                    benchmark=label,
                )
                rec["Truncated"] = 1
                rec["Truncation Strategy"] = "prompt_too_long"
                rec["Prompt Tokens"] = fit.prompt_tokens
                rec["Chat Template Applied"] = int(bool(fit.chat_applied))
            elif outputs is None:
                rec = R.error_record(
                    scenario_id=s.scenario_id,
                    model_id=spec.id,
                    model_revision=revision,
                    rendered_prompt=fit.text,
                    gen_params=gp,
                    max_model_len=max_model_len,
                    description=f"generation failed: {gen_error}",
                    benchmark=label,
                )
            else:
                text, finish = out_by_todo[i]
                n_out = _count_output_tokens(tokenizer, text)
                rec = R.build_record(
                    scenario_id=s.scenario_id,
                    model_id=spec.id,
                    model_revision=revision,
                    chat_template_applied=fit.chat_applied,
                    rendered_prompt=fit.text,
                    gen_params=gp,
                    max_model_len=max_model_len,
                    prompt_tokens=fit.prompt_tokens,
                    output_tokens=n_out,
                    finish_reason=finish,
                    truncated=fit.truncated,
                    latency_s=avg_latency,
                    output=text,
                    benchmark=label,
                    truncation_strategy=fit.strategy,
                )
            w.write_row(rec)
            written += 1

    # Pair is complete only when every todo item either generated or was a
    # deliberate prompt_too_long Issue (not a batch-level generation failure).
    complete = outputs is not None
    return FRQResult(
        written=written,
        complete=complete,
        status="ok" if complete else "generation_failed",
    )


def dry_run(spec: ModelSpec, scenarios: list, n: int = 3) -> str:
    """Show the message list per benchmark WITHOUT loading a model, so the
    per-benchmark system-prompt selection (e.g. InFoBench omits the system turn)
    is visible at a glance."""
    lines: list[str] = []
    shown: dict[str, int] = {}
    for s in scenarios:
        b = getattr(s, "benchmark", "") or R.BENCHMARK
        if shown.get(b, 0) >= n:
            continue
        shown[b] = shown.get(b, 0) + 1
        msgs = P.build_chat_messages(s)
        roles = [m["role"] for m in msgs]
        lines.append(f"\n-- [{b}] {s.scenario_id} ({s.use_case or '-'}) roles={roles}")
        for m in msgs:
            preview = " ".join(m["content"].split())[:200]
            lines.append(f"   [{m['role']}] {preview}")
    return "\n".join(lines)
